<?php

namespace App\Modules\Auth\Repositories;

use App\BaseRepository\Eloquent\EloquentRepositoryInterface;

interface AuthRepositoryInterface extends EloquentRepositoryInterface
{
    // 
}
