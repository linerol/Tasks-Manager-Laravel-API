<?php

return [
    'key' => 'value',
];