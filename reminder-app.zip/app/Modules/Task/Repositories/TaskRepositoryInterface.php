<?php

namespace App\Modules\Task\Repositories;

use App\BaseRepository\Eloquent\EloquentRepositoryInterface;

interface TaskRepositoryInterface extends EloquentRepositoryInterface
{
    // 
}